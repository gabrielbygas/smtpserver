/* C header files */
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Socket API headers */
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "iniparser.h"

/* Definations */
#define DEFAULT_BUFLEN 512
#define PORT 1863

void do_job(int fd)
{
#define COMPARE(a, b, c) (strncmp(a, b, c) == 0)
#define DEFAULT_BUFLEN 512
#define BUF_SIZE 4096

    int length, rcnt;
    char recvbuf[DEFAULT_BUFLEN], bmsg[DEFAULT_BUFLEN];
    int recvbuflen = DEFAULT_BUFLEN;
    FILE *ofp;

    int lengthWord(char *str)
    {
        int k = strlen(str);
        char search[] = "\n";
        char *ptr = strstr(str, search);
        int l = strlen(ptr);
        int m = k - l;
        return m;
    }

    void removeSubstr(char *string, char *sub)
    {
        char *match;
        int len = strlen(sub);
        while ((match = strstr(string, sub)))
        {
            *match = '\0';
            strcat(string, match + len);
        }
    }

    void makelower(char *string)
    { 
        int i=0;
        while (string[i] != '\0')
        {
            string[i] = tolower(string[i]);
            i++;
        }
        i = 0;
    }

    /*void makelower(char *string)
    {
        int longu = strlen(string);
        int i;
        for (i = 0; i < longu; i++)
        {
            if (isupper(string[i]))
            {
                string[i] += 'a' - 'A';
            }
        }
        string[longu] = '\0';
    }*/

    int rc, i, j;
    char buffer[BUF_SIZE], bufferout[BUF_SIZE];
    int buffer_offset = 0;
    buffer[BUF_SIZE - 1] = '\0';
    int inmessage = 0;

    dictionary *ini;
    int b;
    int z;
    double d;
    const char *s;
    const char *sf;
    char tampon[500], senderdom[500], emailsender[500], emailrecv[500], themessage[500];
    ini = iniparser_load("server.ini"); ////iniparser initialisation
    if (ini == NULL)
    {
        fprintf(stderr, "The server.ini is not in this directory \n");
    }
   
    char start[] = "\r\n";
    sprintf(themessage, "%i", start);
   
    iniparser_dump(ini, stderr);

    s = iniparser_getstring(ini, "server:Servername", NULL);
    sf = iniparser_getstring(ini, "server:Domainname", NULL);
    
    sprintf(bufferout, "220 %s <%s>\r\n", s, sf);

    printf("%s", bufferout);
    send(fd, bufferout, strlen(bufferout), 0);

    // Receive until the peer shuts down the connection
    do
    {

        // Clear Receive buffer
        memset(&recvbuf, '\0', sizeof(recvbuf));
        rcnt = recv(fd, recvbuf, recvbuflen, 0);
        if (rcnt > 0)
        {
            const char *gf;
            char helo[] = "Helo";
            char mail[] = "mail from:";
            char rcpt[] = "rcpt to:";
            char data[] = "data";
            int he, ma, rcp, da;
            he = strlen(helo);
            ma = strlen(mail);
            rcp = strlen(rcpt);
            da = strlen(data);

            sprintf(tampon, "%s", recvbuf);
            if (!inmessage)
            { 
                printf("C: %s\n", recvbuf);
                int longrecv = strlen(recvbuf);
                // Replace all lower case letters so verbs are all caps
                
                for (i = 0; i < longrecv; i++)
                {
                    if (islower(recvbuf[i]))
                    {
                        recvbuf[i] += 'A' - 'a';
                    }
                }
                recvbuf[longrecv] = '\0';


                if (COMPARE(recvbuf, "HELO", he))
                {   
                    sprintf(senderdom, "%s", recvbuf);
                    removeSubstr(senderdom, "HELO"); //remove HELO
                    removeSubstr(senderdom, " ");    //remove space
                    removeSubstr(senderdom, "\r\n");

                    makelower(senderdom); //make it lower

                    printf(senderdom);
                    sprintf(bufferout, "250 ,Hello %s , please to meet you\r\n", senderdom);
                    printf("250 Hello %s , please to meet you", senderdom);
                    send(fd, bufferout, strlen(bufferout), 0);
                }
                else if (COMPARE(recvbuf, "MAIL FROM:", ma))
                {   
                    sprintf(emailsender, "%s", recvbuf);
                    removeSubstr(emailsender, "MAIL FROM:"); //remove MAIL FROM:
                    removeSubstr(emailsender, " ");          //remove space
                    removeSubstr(emailsender, "\r\n");       //remove \r\n

                    makelower(emailsender); //make it lower

                    printf(emailsender);
                    sprintf(bufferout, "250 %s... Sender ok\r\n", emailsender); //
                    printf("250 %s... Sender ok", emailsender);
                    send(fd, bufferout, strlen(bufferout), 0);
                }
                else if (COMPARE(recvbuf, "RCPT TO:", rcp))
                {   
                    sprintf(emailrecv, "%s", recvbuf);
                    removeSubstr(emailrecv, "RCPT TO:"); //remove HELO
                    removeSubstr(emailrecv, " ");        //remove space
                    removeSubstr(emailrecv, "\r\n");     //remove space
                                                         //make it lower
                    makelower(emailrecv);                //valeur bar.com en minuscule

                    printf(emailrecv);
                    sprintf(bufferout, "250 %s... Recipient ok\r\n", emailrecv); //
                    printf("250 %s... Recipient ok", emailrecv);
                    send(fd, bufferout, strlen(bufferout), 0);
                }
                else if (COMPARE(recvbuf, "DATA", da))
                { // Message contents...
                    sprintf(bufferout, "354 Enter mail, end with \".\" on a line by itself\r\n");
                    send(fd, bufferout, strlen(bufferout), 0); ///

                    sprintf(bufferout, "To: %s \r\n", emailrecv);
                    send(fd, bufferout, strlen(bufferout), 0); // email

                    sprintf(bufferout, "Subject: This is test message for SMTP server\r\n");
                    send(fd, bufferout, strlen(bufferout), 0);

                    sprintf(bufferout, "From: Example Sender<%s>\r\n", emailsender);
                    send(fd, bufferout, strlen(bufferout), 0); // sender email

                    sprintf(bufferout, "Date: \r\n");
                    send(fd, bufferout, strlen(bufferout), 0); //date and heure

                    inmessage = 1;
                }
                else if (COMPARE(recvbuf, "QUIT", 4))
                { // Close the connection
                    sprintf(bufferout, "221 %s Closing connection\r\n", sf);
                    printf("S: %s", bufferout);
                    const char *kf;
                    char fichier[500];
                    char sfile[] = "response.mbox";
                    sprintf(fichier, "%s", kf);
                    kf = iniparser_getstring(ini, "server:ServerRoot", NULL);
                    //strcat(fichier, sfile);
                    printf("%s\r\n", kf);

                    ofp = fopen(sfile, "w");
                    fprintf(ofp, "To: %s \r\n", emailrecv);
                    fprintf(ofp, "Subject: This is test message for SMTP server\r\n");
                    fprintf(ofp, "From: Example Sender<%s>\r\n", emailsender);
                    fprintf(ofp, "Date: \r\n");
                    fprintf(ofp, "\r\n%s", themessage);
                    fclose(ofp);

                    send(fd, bufferout, strlen(bufferout), 0);
                    close(fd);
                    break;
                }
                else
                { // The verb used hasn't been implemented.
                    sprintf(bufferout, "502 Command Not Implemented\r\n");
                    printf("S: %s", bufferout);
                    send(fd, bufferout, strlen(bufferout), 0);
                }
            }
            else
            { // We are inside the message after a DATA verb.
                printf("C%d: %s\n", fd, buffer);
                strcat(themessage, recvbuf);
                if (COMPARE(recvbuf, ".", 1))
                { // A single "." signifies the end
                    sprintf(bufferout, "250 Message accepted for delivery \r\n");
                    printf("S%d: %s", fd, bufferout);
                    send(fd, bufferout, strlen(bufferout), 0);
                    inmessage = 0;
                }
            }
            ////////////////////////////////////////////////////////////////////////
            if (rcnt < 0)
            {
                printf("Send failed:\n");
                close(fd);
                break;
            }
            printf("Bytes sent: %d\n", rcnt);
        }
        else if (rcnt == 0)
            printf("Connection closing...\n");
        else
        {
            printf("Receive failed:\n");
            close(fd);
            break;
        }
    } while (rcnt > 0);
}

int main()
{
    int server, client;
    struct sockaddr_in local_addr;
    struct sockaddr_in remote_addr;
    int length, fd, rcnt, optval;
    pid_t pid;

    /* Open socket descriptor */
    if ((server = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        perror("Can't create socket!");
        return (1);
    }

    /* Fill local and remote address structure with zero */
    memset(&local_addr, 0, sizeof(local_addr));
    memset(&remote_addr, 0, sizeof(remote_addr));

    /* Set values to local_addr structure */
    local_addr.sin_family = AF_INET;
    local_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    local_addr.sin_port = htons(PORT);

    // set SO_REUSEADDR on a socket to true (1):
    optval = 1;
    setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof optval);

    if (bind(server, (struct sockaddr *)&local_addr, sizeof(local_addr)) < 0)
    {
        /* could not start server */
        perror("Bind error");
        return (1);
    }

    if (listen(server, SOMAXCONN) < 0)
    {
        perror("listen");
        exit(1);
    }

    printf("Concurrent  socket server now starting on port %d\n", PORT);
    printf("Wait for connection\n");

    while (1)
    { // main accept() loop
        length = sizeof remote_addr;
        if ((fd = accept(server, (struct sockaddr *)&remote_addr,
                         &length)) == -1)
        {
            perror("Accept Problem!");
            continue;
        }

        printf("Server: got connection from %s\n",
               inet_ntoa(remote_addr.sin_addr));

        /* If fork create Child, take control over child and close on server side */
        if ((pid = fork()) == 0)
        {
            close(server);
            do_job(fd);
            printf("Child finished their job!\n");
            close(fd);
            exit(0);
        }
    }

    // Final Cleanup
    close(server);
}